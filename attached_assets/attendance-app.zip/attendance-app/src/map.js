import { getDatabase, ref, onValue } from "firebase/database";

function loadEmployeesOnMap(map) {
    const db = getDatabase();
    const employeesRef = ref(db, 'employees');

    onValue(employeesRef, (snapshot) => {
        const employees = snapshot.val();
        if (employees) {
            Object.keys(employees).forEach((employeeId) => {
                const { location } = employees[employeeId];
                // Agregar marcador al mapa
                addMarkerToMap(map, location, employeeId);
            });
        }
    });
}

function addMarkerToMap(map, location, employeeId) {
    // Ejemplo con Google Maps
    new google.maps.Marker({
        position: location,
        map: map,
        title: `Empleado: ${employeeId}`
    });
}