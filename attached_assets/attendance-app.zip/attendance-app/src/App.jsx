
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import EmployeeDashboard from '@/pages/EmployeeDashboard';
import AdminLogin from '@/pages/AdminLogin';
import AdminDashboard from '@/pages/AdminDashboard';
import HelpPage from '@/pages/HelpPage';
import CheckInPage from '@/pages/CheckInPage';
import MapViewPage from '@/pages/MapViewPage';
import { EmployeeProvider } from '@/contexts/EmployeeContext';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout'; // Import Layout

const ProtectedAdminRoute = ({ children }) => {
  const { isAdminAuthenticated } = useAuth();
  if (!isAdminAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }
  return children;
};

function App() {
  return (
    <AuthProvider>
      <EmployeeProvider>
        <Layout> {/* Wrap Routes with Layout */}
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<EmployeeDashboard />} />
              <Route path="/check-in" element={<CheckInPage />} />
              <Route path="/map-view" element={<MapViewPage />} />
              <Route path="/help" element={<HelpPage />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route 
                path="/admin/dashboard" 
                element={
                  <ProtectedAdminRoute>
                    <AdminDashboard />
                  </ProtectedAdminRoute>
                } 
              />
               {/* Fallback route for any undefined paths */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </AnimatePresence>
        </Layout>
      </EmployeeProvider>
    </AuthProvider>
  );
}

export default App;
