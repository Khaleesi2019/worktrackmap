
import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { useEmployees } from '@/contexts/EmployeeContext';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

function AdminMapController({ locations }) {
  const map = useMap();
  useEffect(() => {
    if (locations && locations.length > 0) {
      const bounds = L.latLngBounds(locations.map(loc => [loc.lat, loc.lng]));
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    } else {
       map.setView([19.4326, -99.1332], 5);
    }
  }, [locations, map]);
  return null;
}

const EmployeeMap = ({ employeeLogs }) => { 
  const [activeEmployeesLocations, setActiveEmployeesLocations] = useState([]);

  useEffect(() => {
    if (employeeLogs) {
      const active = employeeLogs
        .filter(log => log.status === 'active' && log.locationIn)
        .map(log => ({
          lat: log.locationIn.lat,
          lng: log.locationIn.lng,
          name: log.employeeName,
          project: log.project,
          task: log.task,
          address: log.locationIn.address,
          lastUpdate: log.lastLocationUpdate
        }));
      setActiveEmployeesLocations(active);
    }
  }, [employeeLogs]);
  
  const employeeMarkerIcon = (name) => L.divIcon({
    className: 'custom-admin-marker',
    html: `<div class="flex flex-col items-center">
             <div class="p-2 bg-primary rounded-full shadow-lg">
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>
             </div>
             <span class="mt-1 text-xs font-semibold bg-white px-1.5 py-0.5 rounded shadow">${name.split(' ')[0]}</span>
           </div>`,
    iconSize: [30, 40],
    iconAnchor: [15, 40],
  });

  const getTimeAgo = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true, locale: es });
    } catch (error) {
      return 'fecha desconocida';
    }
  };

  return (
    <Card className="shadow-lg border-0 overflow-hidden">
      <CardContent className="p-0">
        <div className="h-[450px] sm:h-[500px] relative admin-map-container">
          <MapContainer center={[19.4326, -99.1332]} zoom={5} className="h-full w-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <AdminMapController locations={activeEmployeesLocations} />
            {activeEmployeesLocations.map((loc, idx) => (
              <Marker key={idx} position={[loc.lat, loc.lng]} icon={employeeMarkerIcon(loc.name)}>
                <Popup>
                  <div className="text-sm">
                    <p className="font-bold text-primary">{loc.name}</p>
                    <p><strong>Proyecto:</strong> {loc.project}</p>
                    <p><strong>Tarea:</strong> {loc.task}</p>
                    <p className="flex items-center"><MapPin size={14} className="mr-1 text-gray-500" /> {loc.address}</p>
                    <p className="flex items-center"><Clock size={14} className="mr-1 text-gray-500" /> Últ. Act.: {getTimeAgo(loc.lastUpdate)}</p>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default EmployeeMap;
