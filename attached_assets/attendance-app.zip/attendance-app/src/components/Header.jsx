
import React from 'react';
import { Building2 } from 'lucide-react';
import { motion } from 'framer-motion';

const Header = ({ title }) => {
  return (
    <motion.header 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white shadow-sm p-4 sticky top-0 z-50"
    >
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <Building2 className="h-8 w-8 text-primary mr-3" />
          <h1 className="text-xl font-semibold text-gray-800">
            Master Construction {title ? `- ${title}` : ''}
          </h1>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
