import { getDatabase, ref, set } from "firebase/database";

function saveEmployeeLocation(employeeId, location) {
    const db = getDatabase();
    set(ref(db, `employees/${employeeId}`), {
        location: location,
        timestamp: Date.now()
    });
}

const initialData = {
    "employees": {
        "employeeId1": {
            "location": { "lat": 19.4326, "lng": -99.1332 },
            "timestamp": 1683984000000
        },
        "employeeId2": {
            "location": { "lat": 40.7128, "lng": -74.0060 },
            "timestamp": 1683987600000
        }
    }
};