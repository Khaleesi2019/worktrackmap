
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useEmployees } from '@/contexts/EmployeeContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { LogOut, Users, MapPin, Clock, Search, Building2, Filter, Download, PlusCircle, Send, ListOrdered, CalendarDays } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import L from 'leaflet';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const AdminMapController = ({ locations, selectedLog }) => {
  const map = useMap();
  useEffect(() => {
    if (selectedLog && selectedLog.locationIn) {
        map.setView([selectedLog.locationIn.lat, selectedLog.locationIn.lng], 15);
    } else if (locations && locations.length > 0) {
      const bounds = L.latLngBounds(locations.map(loc => [loc.lat, loc.lng]));
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    } else {
       map.setView([19.4326, -99.1332], 10); 
    }
  }, [locations, map, selectedLog]);
  return null;
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { adminLogout } = useAuth();
  const { employeeLogs, calculateHours, loading: employeesLoading, addFutureAssignment, futureAssignments } = useEmployees();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [activeEmployeesLocations, setActiveEmployeesLocations] = useState([]);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [assignmentData, setAssignmentData] = useState({
    employeeName: '',
    employeeId: '', 
    project: '',
    task: '',
    date: format(new Date(), 'yyyy-MM-dd')
  });
  const [uniqueEmployeeNames, setUniqueEmployeeNames] = useState([]);
  const [selectedLogForMap, setSelectedLogForMap] = useState(null);

  useEffect(() => {
    const lowerSearchTerm = searchTerm.toLowerCase();
    const logs = employeeLogs
      .filter(log => 
        log.employeeName.toLowerCase().includes(lowerSearchTerm) ||
        log.project.toLowerCase().includes(lowerSearchTerm) ||
        log.task.toLowerCase().includes(lowerSearchTerm)
      )
      .sort((a, b) => new Date(b.timeIn) - new Date(a.timeIn)); 
    setFilteredLogs(logs);

    const active = logs
      .filter(log => log.status === 'active' && log.locationIn)
      .map(log => ({
        lat: log.locationIn.lat,
        lng: log.locationIn.lng,
        name: log.employeeName,
        avatarInitial: log.avatarInitial || log.employeeName.charAt(0).toUpperCase(),
        project: log.project,
        task: log.task,
        address: log.locationIn.address,
        lastUpdate: log.lastLocationUpdate
      }));
    setActiveEmployeesLocations(active);
    
    const names = [...new Set(employeeLogs.map(log => log.employeeName))];
    setUniqueEmployeeNames(names);

  }, [searchTerm, employeeLogs]);

  const formatDate = (dateString, fmt = "dd/MM/yy HH:mm") => {
    if (!dateString) return 'N/A';
    return format(new Date(dateString), fmt, { locale: es });
  };
  
  const employeeMarkerIcon = (initial) => L.divIcon({
    className: 'custom-avatar-marker',
    html: `<div class="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center text-lg font-bold shadow-lg border-2 border-white transform hover:scale-110 transition-transform">
             ${initial}
           </div>
           <div class="w-3 h-3 bg-primary absolute bottom-0 right-0 rounded-full border-2 border-white"></div>`,
    iconSize: [40, 40],
    iconAnchor: [20, 40], // Anchor at bottom center of the circle
    popupAnchor: [0, -40] // Popup above the marker
  });

  const handleAssignTask = () => {
    if (!assignmentData.employeeName || !assignmentData.project || !assignmentData.task || !assignmentData.date) {
        alert("Por favor complete todos los campos para la asignación.");
        return;
    }
    const selectedEmployeeLog = employeeLogs.find(log => log.employeeName === assignmentData.employeeName);
    addFutureAssignment({
        ...assignmentData,
        employeeId: selectedEmployeeLog ? (selectedEmployeeLog.employeeId || selectedEmployeeLog.employeeName.toLowerCase().replace(/\s+/g, '-')) : assignmentData.employeeName.toLowerCase().replace(/\s+/g, '-')
    });
    setIsAssignDialogOpen(false);
    setAssignmentData({ employeeName: '', employeeId: '', project: '', task: '', date: format(new Date(), 'yyyy-MM-dd') });
  };
  
  const handleAssignmentInputChange = (e) => {
    const { name, value } = e.target;
    setAssignmentData(prev => ({ ...prev, [name]: value }));
  };

  const handleEmployeeSelectionForAssignment = (employeeName) => {
    setAssignmentData(prev => ({ ...prev, employeeName }));
  };
  
  const exportData = (dataToExport, fileNamePrefix) => {
    let csvHeader, csvRows;
    if (fileNamePrefix === 'registros') {
        csvHeader = "Nombre,Teléfono,Proyecto,Tarea,Entrada,Salida,Horas,Ubicación Entrada,Ubicación Salida\n";
        csvRows = dataToExport.map(log => 
          [
            `"${log.employeeName}"`, `"${log.phone || 'N/A'}"`, `"${log.project}"`, `"${log.task}"`,
            `"${formatDate(log.timeIn)}"`, `"${formatDate(log.timeOut)}"`, `"${calculateHours(log.timeIn, log.timeOut)}"`,
            `"${log.locationIn ? log.locationIn.address.replace(/"/g, '""') : 'N/A'}"`,
            `"${log.locationOut ? log.locationOut.address.replace(/"/g, '""') : 'N/A'}"`
          ].join(',')
        ).join('\n');
    } else if (fileNamePrefix === 'asignaciones') {
        csvHeader = "Empleado,Proyecto,Tarea,Fecha Asignada,Fecha de Creación\n";
        csvRows = dataToExport.map(assign =>
          [
            `"${assign.employeeName}"`, `"${assign.project}"`, `"${assign.task}"`,
            `"${formatDate(assign.date, 'dd/MM/yyyy')}"`, `"${formatDate(assign.assignedAt)}"`
          ].join(',')
        ).join('\n');
    }
    
    const csvContent = csvHeader + csvRows;
    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' }); // Added BOM for Excel
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `${fileNamePrefix}_master_construction_${format(new Date(), "yyyyMMdd")}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-800 text-white p-4 shadow-lg sticky top-0 z-[1000]">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <Building2 className="h-8 w-8 mr-3 text-primary" />
            <h1 className="text-2xl font-bold">Admin - Master Construction</h1>
          </div>
          <Button onClick={adminLogout} variant="destructive" size="sm" className="bg-red-600 hover:bg-red-700">
            <LogOut className="h-4 w-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </header>

      <main className="container mx-auto p-4 sm:p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="mb-6 shadow-xl border-gray-200 bg-white">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-700">Mapa de Empleados Activos</CardTitle>
              <CardDescription>Visualiza la ubicación en tiempo real de los empleados con sesión activa.</CardDescription>
            </CardHeader>
            <CardContent className="admin-map-container">
              {employeesLoading ? (
                <p className="text-center py-10">Cargando mapa...</p>
              ) : (
                <MapContainer center={[19.4326, -99.1332]} zoom={10} style={{ height: '450px', borderRadius: '0.5rem' }} className="shadow-inner">
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <AdminMapController locations={activeEmployeesLocations} selectedLog={selectedLogForMap}/>
                  {activeEmployeesLocations.map((loc, idx) => (
                    <Marker key={idx} position={[loc.lat, loc.lng]} icon={employeeMarkerIcon(loc.avatarInitial)}>
                      <Popup>
                        <div className="text-sm space-y-0.5">
                          <p className="font-bold text-primary text-base">{loc.name}</p>
                          <p><strong>Proyecto:</strong> {loc.project}</p>
                          <p><strong>Tarea:</strong> {loc.task}</p>
                          <p className="flex items-center"><MapPin size={14} className="mr-1 text-gray-500 flex-shrink-0" /> {loc.address}</p>
                          <p className="flex items-center"><Clock size={14} className="mr-1 text-gray-500 flex-shrink-0" /> Últ. Act.: {format(new Date(loc.lastUpdate), "HH:mm", { locale: es })}</p>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                </MapContainer>
              )}
            </CardContent>
          </Card>
          
          <Tabs defaultValue="logs" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 mb-4 bg-gray-200 p-1 rounded-lg">
              <TabsTrigger value="logs" className="data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-md py-2.5">Registros Diarios</TabsTrigger>
              <TabsTrigger value="assignments" className="data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-md py-2.5">Asignaciones Futuras</TabsTrigger>
              <TabsTrigger value="manage" className="data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-md py-2.5 col-span-2 md:col-span-1">Gestionar Tareas</TabsTrigger>
            </TabsList>

            <TabsContent value="logs">
              <Card className="shadow-xl border-gray-200 bg-white">
                <CardHeader>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <CardTitle className="text-2xl text-gray-700">Registros de Empleados</CardTitle>
                      <CardDescription>Historial de entradas, salidas y ubicaciones.</CardDescription>
                    </div>
                    <Button onClick={() => exportData(filteredLogs, 'registros')} variant="outline" className="elegant-button border-primary text-primary hover:bg-primary hover:text-white">
                        <Download className="h-4 w-4 mr-2" />
                        Exportar Registros (CSV)
                    </Button>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <div className="relative flex-grow">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input
                        placeholder="Buscar por nombre, proyecto, tarea..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 h-11 border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {employeesLoading ? (
                    <p className="text-center py-10">Cargando registros...</p>
                  ) : filteredLogs.length === 0 ? (
                     <p className="text-center text-gray-500 py-10">No se encontraron registros con los filtros actuales.</p>
                  ) : (
                    <div className="overflow-x-auto rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-100 hover:bg-gray-100">
                            <TableHead className="font-semibold text-gray-700">Nombre</TableHead>
                            <TableHead className="font-semibold text-gray-700">Proyecto</TableHead>
                            <TableHead className="font-semibold text-gray-700">Tarea</TableHead>
                            <TableHead className="font-semibold text-gray-700 text-center">Entrada</TableHead>
                            <TableHead className="font-semibold text-gray-700 text-center">Salida</TableHead>
                            <TableHead className="font-semibold text-gray-700 text-center">Horas</TableHead>
                            <TableHead className="font-semibold text-gray-700">Ubic. Entrada</TableHead>
                            <TableHead className="font-semibold text-gray-700">Ubic. Salida</TableHead>
                             <TableHead className="font-semibold text-gray-700 text-center">Mapa</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredLogs.map((log) => (
                            <TableRow key={log.id} className="hover:bg-blue-50 transition-colors duration-150">
                              <TableCell className="font-medium text-gray-800 py-3">{log.employeeName}</TableCell>
                              <TableCell className="text-gray-600 py-3">{log.project}</TableCell>
                              <TableCell className="text-gray-600 py-3">{log.task}</TableCell>
                              <TableCell className="text-gray-600 text-center py-3">{formatDate(log.timeIn)}</TableCell>
                              <TableCell className={`text-center py-3 ${log.status === 'active' ? 'text-green-600 font-semibold' : 'text-gray-600'}`}>{log.timeOut ? formatDate(log.timeOut) : 'Activo'}</TableCell>
                              <TableCell className="text-gray-600 text-center font-medium py-3">{calculateHours(log.timeIn, log.timeOut)}</TableCell>
                              <TableCell className="text-xs text-gray-500 max-w-[150px] truncate py-3" title={log.locationIn?.address}>{log.locationIn?.address || 'N/A'}</TableCell>
                              <TableCell className="text-xs text-gray-500 max-w-[150px] truncate py-3" title={log.locationOut?.address}>{log.locationOut?.address || 'N/A'}</TableCell>
                              <TableCell className="text-center py-3">
                                <Button variant="ghost" size="icon" onClick={() => setSelectedLogForMap(log)} className="hover:bg-primary/10">
                                    <MapPin className="h-5 w-5 text-primary"/>
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="assignments">
                <Card className="shadow-xl border-gray-200 bg-white">
                    <CardHeader>
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                            <div>
                                <CardTitle className="text-2xl text-gray-700">Asignaciones Futuras</CardTitle>
                                <CardDescription>Tareas programadas para los empleados.</CardDescription>
                            </div>
                             <Button onClick={() => exportData(futureAssignments, 'asignaciones')} variant="outline" className="elegant-button border-primary text-primary hover:bg-primary hover:text-white">
                                <Download className="h-4 w-4 mr-2" />
                                Exportar Asignaciones (CSV)
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        {futureAssignments.length === 0 ? (
                            <p className="text-center text-gray-500 py-10">No hay asignaciones futuras programadas.</p>
                        ) : (
                            <div className="overflow-x-auto rounded-md border">
                                <Table>
                                    <TableHeader>
                                        <TableRow className="bg-gray-100 hover:bg-gray-100">
                                            <TableHead className="font-semibold text-gray-700">Empleado</TableHead>
                                            <TableHead className="font-semibold text-gray-700">Fecha Asignada</TableHead>
                                            <TableHead className="font-semibold text-gray-700">Proyecto</TableHead>
                                            <TableHead className="font-semibold text-gray-700">Tarea</TableHead>
                                            <TableHead className="font-semibold text-gray-700">Fecha de Creación</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {futureAssignments.sort((a,b) => new Date(a.date) - new Date(b.date)).map(assign => (
                                            <TableRow key={assign.id} className="hover:bg-blue-50 transition-colors duration-150">
                                                <TableCell className="font-medium text-gray-800 py-3">{assign.employeeName}</TableCell>
                                                <TableCell className="text-gray-600 py-3">{formatDate(assign.date, 'PPP')}</TableCell>
                                                <TableCell className="text-gray-600 py-3">{assign.project}</TableCell>
                                                <TableCell className="text-gray-600 py-3">{assign.task}</TableCell>
                                                <TableCell className="text-xs text-gray-500 py-3">{formatDate(assign.assignedAt)}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>
            
            <TabsContent value="manage">
                <Card className="shadow-xl border-gray-200 bg-white">
                    <CardHeader>
                        <CardTitle className="text-2xl text-gray-700">Asignar Nueva Tarea</CardTitle>
                        <CardDescription>Programa futuras tareas para tus empleados.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div>
                            <Label htmlFor="employeeNameAssign" className="font-medium text-gray-700">Empleado</Label>
                             <Select onValueChange={handleEmployeeSelectionForAssignment} value={assignmentData.employeeName}>
                                <SelectTrigger className="w-full h-11 mt-1 border-gray-300 focus:border-primary focus:ring-primary shadow-sm">
                                    <SelectValue placeholder="Seleccionar empleado" />
                                </SelectTrigger>
                                <SelectContent>
                                    {uniqueEmployeeNames.map(name => (
                                        <SelectItem key={name} value={name}>{name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label htmlFor="dateAssign" className="font-medium text-gray-700">Fecha de la Tarea</Label>
                            <Input 
                                type="date" 
                                id="dateAssign" 
                                name="date" 
                                value={assignmentData.date} 
                                onChange={handleAssignmentInputChange}
                                className="h-11 mt-1 border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                            />
                        </div>
                        <div>
                            <Label htmlFor="projectAssign" className="font-medium text-gray-700">Proyecto</Label>
                            <Input 
                                id="projectAssign" 
                                name="project" 
                                value={assignmentData.project} 
                                onChange={handleAssignmentInputChange} 
                                placeholder="Nombre del proyecto"
                                className="h-11 mt-1 border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                            />
                        </div>
                        <div>
                            <Label htmlFor="taskAssign" className="font-medium text-gray-700">Descripción de la Tarea</Label>
                            <Textarea 
                                id="taskAssign" 
                                name="task" 
                                value={assignmentData.task} 
                                onChange={handleAssignmentInputChange} 
                                placeholder="Detalles de la tarea a realizar"
                                className="mt-1 border-gray-300 focus:border-primary focus:ring-primary shadow-sm min-h-[100px]"
                            />
                        </div>
                        <Button onClick={handleAssignTask} className="w-full sm:w-auto bg-primary hover:bg-blue-700 text-white h-11 text-base">
                            <Send className="h-4 w-4 mr-2" />
                            Asignar Tarea
                        </Button>
                    </CardContent>
                </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  );
};

export default AdminDashboard;

