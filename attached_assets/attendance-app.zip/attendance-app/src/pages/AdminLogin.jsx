
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Shield, Building2, Delete } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const AdminLogin = () => {
  const navigate = useNavigate();
  const { adminLogin } = useAuth();
  const { toast } = useToast();
  const [pin, setPin] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handlePinInput = (digit) => {
    if (pin.length < 4) {
      setPin(pin + digit);
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (pin.length !== 4) {
      toast({
        title: "PIN incompleto",
        description: "El PIN debe tener 4 dígitos.",
        variant: "destructive",
      });
      return;
    }
    setIsLoading(true);
    const success = adminLogin(pin);
    if (!success) {
      setPin(''); // Clear PIN on failure
    }
    setIsLoading(false);
  };

  const pinPadNumbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0'];

  return (
    <div className="min-h-screen bg-gray-800 flex flex-col items-center justify-center p-4 text-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <Building2 className="mx-auto h-16 w-16 text-primary mb-4" />
        <h1 className="text-4xl font-bold">Master Construction</h1>
        <p className="text-xl text-gray-300 mt-2">Acceso de Administrador</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full max-w-sm"
      >
        <Card className="bg-gray-700 border-gray-600 shadow-2xl">
          <CardHeader className="text-center">
            <Shield className="mx-auto h-12 w-12 text-primary mb-3" />
            <CardTitle className="text-2xl">Ingresar PIN</CardTitle>
            <CardDescription className="text-gray-400">Utiliza el teclado numérico.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <div className="flex justify-center mb-6">
                <Input
                  type="password"
                  value={pin}
                  readOnly
                  className="w-48 h-16 text-4xl text-center tracking-[0.5em] bg-gray-800 border-gray-600 text-white focus:ring-primary"
                  maxLength={4}
                />
              </div>

              <div className="grid grid-cols-3 gap-3 mb-6">
                {pinPadNumbers.map((num, idx) => (
                  num ? (
                    <Button
                      key={idx}
                      type="button"
                      onClick={() => handlePinInput(num)}
                      className="pin-pad-button bg-gray-600 hover:bg-gray-500 text-white"
                      disabled={isLoading}
                    >
                      {num}
                    </Button>
                  ) : <div key={idx}></div> 
                ))}
                 <Button
                    type="button"
                    onClick={handleDelete}
                    className="pin-pad-button bg-red-600 hover:bg-red-500 text-white col-start-3"
                    disabled={isLoading || pin.length === 0}
                  >
                    <Delete size={28} />
                  </Button>
              </div>
              
              <Button 
                type="submit" 
                className="w-full h-14 text-lg bg-primary hover:bg-blue-600 text-white font-semibold"
                disabled={isLoading || pin.length !== 4}
              >
                {isLoading ? 'Verificando...' : 'Acceder'}
              </Button>
            </form>
          </CardContent>
        </Card>
         <Button variant="link" className="mt-8 text-gray-400 hover:text-gray-200 w-full" onClick={() => navigate('/')}>
            Ir al Portal de Empleados
        </Button>
      </motion.div>
    </div>
  );
};

export default AdminLogin;
