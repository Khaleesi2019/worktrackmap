
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, User, MapPin, Clock, Building2 } from 'lucide-react';
import { useEmployees } from '@/contexts/EmployeeContext';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import { motion } from 'framer-motion';

const MapUpdater = ({ location }) => {
  const map = useMap();
  useEffect(() => {
    if (location) {
      map.setView([location.lat, location.lng], 15);
    }
  }, [location, map]);
  return null;
};

const MapViewPage = () => {
  const navigate = useNavigate();
  const { currentEmployee, updateCurrentEmployeeLocation, getCurrentLocation } = useEmployees();
  const [mapLocation, setMapLocation] = useState(null);

  useEffect(() => {
    if (currentEmployee && currentEmployee.locationIn) {
      setMapLocation(currentEmployee.locationIn);
    } else {
      // If no current employee or no location, try to get current device location
      getCurrentLocation((loc) => {
        if (loc) setMapLocation(loc);
        else setMapLocation({ lat: 19.4326, lng: -99.1332, address: "Ubicación por defecto" }); // Mexico City
      });
    }
  }, [currentEmployee]);

  useEffect(() => {
    // Periodically update location if employee is active
    const interval = setInterval(() => {
      if (currentEmployee && currentEmployee.status === 'active') {
        updateCurrentEmployeeLocation();
      }
    }, 5 * 60 * 1000); // Update every 5 minutes for demo, original was 30 min
    return () => clearInterval(interval);
  }, [currentEmployee, updateCurrentEmployeeLocation]);

  const employeeMarkerIcon = L.divIcon({
    className: 'custom-employee-marker',
    html: `<div class="relative">
             <div class="p-1 bg-primary rounded-full shadow-lg">
               <div class="w-3 h-3 bg-white rounded-full"></div>
             </div>
             <div class="absolute top-0 left-0 w-5 h-5 bg-primary opacity-50 rounded-full animate-ping"></div>
           </div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
  });
  
  const getTimeAgo = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true, locale: es });
    } catch (error) {
      return 'fecha desconocida';
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col p-0">
      <header className="bg-white shadow-md p-4 flex items-center justify-between sticky top-0 z-50">
        <Button variant="ghost" onClick={() => navigate('/')} className="text-primary hover:bg-blue-50">
          <ArrowLeft className="h-5 w-5 mr-2" />
          Volver
        </Button>
        <div className="flex items-center">
          <Building2 className="h-6 w-6 text-primary mr-2" />
          <h1 className="text-xl font-semibold text-gray-800">Master Construction - Mi Ubicación</h1>
        </div>
        <div></div>
      </header>

      <main className="flex-grow relative">
        {mapLocation ? (
          <MapContainer center={[mapLocation.lat, mapLocation.lng]} zoom={15} className="h-full w-full absolute inset-0">
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <MapUpdater location={mapLocation} />
            {currentEmployee && currentEmployee.status === 'active' && currentEmployee.locationIn && (
              <Marker position={[currentEmployee.locationIn.lat, currentEmployee.locationIn.lng]} icon={employeeMarkerIcon}>
                <Popup>
                  <div className="text-sm">
                    <p className="font-bold text-primary">{currentEmployee.employeeName}</p>
                    <p className="flex items-center"><MapPin size={14} className="mr-1 text-gray-500" /> {currentEmployee.locationIn.address}</p>
                    <p className="flex items-center"><Clock size={14} className="mr-1 text-gray-500" /> Actualizado: {getTimeAgo(currentEmployee.lastLocationUpdate)}</p>
                  </div>
                </Popup>
              </Marker>
            )}
          </MapContainer>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-600 text-lg">Cargando mapa y ubicación...</p>
          </div>
        )}
      </main>
      
      {currentEmployee && currentEmployee.status === 'active' && (
        <motion.div 
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ type: "spring", stiffness: 100 }}
          className="bg-white p-4 shadow-top fixed bottom-0 left-0 right-0 z-50 border-t border-gray-200"
        >
          <CardContent className="p-0">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Información Actual</h3>
            <div className="space-y-1 text-sm text-gray-700">
              <p><strong className="text-gray-600">Nombre:</strong> {currentEmployee.employeeName}</p>
              <p><strong className="text-gray-600">Proyecto:</strong> {currentEmployee.project}</p>
              <p><strong className="text-gray-600">Tarea:</strong> {currentEmployee.task}</p>
              {currentEmployee.locationIn && (
                <>
                  <p><strong className="text-gray-600">Ubicación:</strong> {currentEmployee.locationIn.address}</p>
                  <p><strong className="text-gray-600">Última Act.:</strong> {getTimeAgo(currentEmployee.lastLocationUpdate)}</p>
                </>
              )}
            </div>
          </CardContent>
        </motion.div>
      )}
    </div>
  );
};

export default MapViewPage;
