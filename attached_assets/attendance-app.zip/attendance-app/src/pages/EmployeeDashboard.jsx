
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { LogIn, LogOut, Map, HelpCircle, Building2, ListChecks, UserCircle } from 'lucide-react';
import { useEmployees } from '@/contexts/EmployeeContext';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const EmployeeDashboard = () => {
  const navigate = useNavigate();
  const { currentEmployee, checkOut, getTodaysAssignmentsForEmployee } = useEmployees();
  const { toast } = useToast();
  const [todaysAssignments, setTodaysAssignments] = useState([]);

  useEffect(() => {
    if (currentEmployee && currentEmployee.employeeName) {
      setTodaysAssignments(getTodaysAssignmentsForEmployee(currentEmployee.employeeName));
    } else if (localStorage.getItem('lastCheckedInUserName')) { // Attempt to load for non-logged-in user
        const lastUserName = localStorage.getItem('lastCheckedInUserName');
        if(lastUserName) setTodaysAssignments(getTodaysAssignmentsForEmployee(lastUserName));
    }
  }, [currentEmployee, getTodaysAssignmentsForEmployee]);

  const handleCheckIn = () => {
    if (currentEmployee && currentEmployee.status === 'active') {
      toast({
        title: "Ya registraste entrada",
        description: "Debes registrar tu salida antes de volver a entrar.",
        variant: "destructive",
      });
    } else {
      navigate('/check-in');
    }
  };

  const handleCheckOut = () => {
    if (!currentEmployee || currentEmployee.status !== 'active') {
      toast({
        title: "No has registrado entrada",
        description: "Debes registrar tu entrada primero.",
        variant: "destructive",
      });
    } else {
      checkOut();
    }
  };

  const buttonVariants = {
    hover: { scale: 1.05, boxShadow: "0px 5px 15px rgba(0,0,0,0.1)" },
    tap: { scale: 0.95 }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 flex flex-col items-center justify-center p-4 selection:bg-primary selection:text-white">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 120 }}
        className="text-center mb-10"
      >
        <Building2 className="mx-auto h-20 w-20 text-primary mb-4 filter drop-shadow-md" />
        <h1 className="text-5xl font-extrabold text-gray-800 tracking-tight">Master Construction</h1>
        <p className="text-xl text-gray-600 mt-3">Portal de Empleados</p>
      </motion.div>

      {currentEmployee && currentEmployee.status === 'active' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay:0.1 }}
          className="mb-8 p-6 bg-green-500 text-white rounded-xl shadow-xl text-center w-full max-w-md"
        >
          <div className="flex items-center justify-center mb-2">
            <UserCircle className="h-7 w-7 mr-2" />
            <p className="text-xl font-semibold">¡Entrada Registrada!</p>
          </div>
          <p className="text-lg">Bienvenido, {currentEmployee.employeeName}.</p>
          <p className="text-sm mt-1">Proyecto: {currentEmployee.project}</p>
          <p className="text-sm">Tarea: {currentEmployee.task}</p>
        </motion.div>
      )}

      {!currentEmployee && todaysAssignments.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-8 w-full max-w-md"
        >
          <Card className="bg-white shadow-lg border-primary border-l-4">
            <CardHeader>
              <CardTitle className="text-lg text-primary flex items-center">
                <ListChecks className="mr-2 h-5 w-5" />
                Tareas Asignadas para Hoy ({format(new Date(), 'PPP', { locale: es })})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              {todaysAssignments.map(assignment => (
                <div key={assignment.id} className="p-2 bg-blue-50 rounded-md">
                  <p><strong>Proyecto:</strong> {assignment.project}</p>
                  <p><strong>Tarea:</strong> {assignment.task}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      )}


      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 w-full max-w-2xl">
        <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
          <Button
            onClick={handleCheckIn}
            className="w-full h-36 text-2xl elegant-button flex-col group hover:border-green-500"
            variant="outline"
            disabled={currentEmployee && currentEmployee.status === 'active'}
          >
            <LogIn className="h-10 w-10 mb-2 text-green-500 group-hover:text-white transition-colors" />
            Entrada
          </Button>
        </motion.div>
        <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
          <Button
            onClick={handleCheckOut}
            className="w-full h-36 text-2xl elegant-button flex-col group hover:border-red-500"
            variant="outline"
            disabled={!currentEmployee || currentEmployee.status !== 'active'}
          >
            <LogOut className="h-10 w-10 mb-2 text-red-500 group-hover:text-white transition-colors" />
            Salida
          </Button>
        </motion.div>
        <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
          <Button
            onClick={() => navigate('/map-view')}
            className="w-full h-36 text-2xl elegant-button flex-col group hover:border-indigo-500"
            variant="outline"
          >
            <Map className="h-10 w-10 mb-2 text-indigo-500 group-hover:text-white transition-colors" />
            Mi Ubicación
          </Button>
        </motion.div>
        <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
          <Button
            onClick={() => navigate('/help')}
            className="w-full h-36 text-2xl elegant-button flex-col group hover:border-amber-500"
            variant="outline"
          >
            <HelpCircle className="h-10 w-10 mb-2 text-amber-500 group-hover:text-white transition-colors" />
            Ayuda
          </Button>
        </motion.div>
      </div>
      <Button variant="link" className="mt-16 text-gray-500 hover:text-primary transition-colors" onClick={() => navigate('/admin/login')}>
        Acceso Administrador
      </Button>
    </div>
  );
};

export default EmployeeDashboard;
