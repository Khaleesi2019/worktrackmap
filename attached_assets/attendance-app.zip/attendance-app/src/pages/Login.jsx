
import React from 'react';
import { Navigate } from 'react-router-dom';

// This page is no longer used for general login.
// Redirecting to the new EmployeeDashboard or AdminLogin.
const Login = () => {
  // Logic to determine if it should be admin or employee,
  // for now, redirecting to employee as a default.
  return <Navigate to="/" replace />;
};

export default Login;
