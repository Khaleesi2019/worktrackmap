
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { User, Phone, Briefcase, ClipboardList, ArrowLeft, Building2, CheckSquare } from 'lucide-react';
import { useEmployees } from '@/contexts/EmployeeContext';
import { useToast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CheckInPage = () => {
  const navigate = useNavigate();
  const { checkIn, currentEmployee, getTodaysAssignmentsForEmployee } = useEmployees();
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedAssignmentId, setSelectedAssignmentId] = useState('');
  const [customProject, setCustomProject] = useState('');
  const [customTask, setCustomTask] = useState('');
  
  const [todaysAssignments, setTodaysAssignments] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const lastUser = localStorage.getItem('lastCheckedInUser');
    if (lastUser) {
      const { name: lastName, phone: lastPhone } = JSON.parse(lastUser);
      setName(lastName || '');
      setPhone(lastPhone || '');
      if (lastName) {
          setTodaysAssignments(getTodaysAssignmentsForEmployee(lastName));
      }
    }
  }, [getTodaysAssignmentsForEmployee]);

  useEffect(() => {
      // If an assignment is selected, populate project and task
      if (selectedAssignmentId) {
          const assignment = todaysAssignments.find(a => a.id === selectedAssignmentId);
          if (assignment) {
              setCustomProject(assignment.project);
              setCustomTask(assignment.task);
          }
      } else {
          // If "Custom" is selected or no assignment, clear project/task for manual input
          setCustomProject('');
          setCustomTask('');
      }
  }, [selectedAssignmentId, todaysAssignments]);


  if (currentEmployee && currentEmployee.status === 'active') {
     navigate('/'); 
     return null;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !phone || !customProject || !customTask) {
      toast({
        title: "Campos incompletos",
        description: "Por favor, rellena Nombre, Teléfono, Proyecto y Tarea.",
        variant: "destructive",
      });
      return;
    }
    setIsSubmitting(true);
    
    localStorage.setItem('lastCheckedInUser', JSON.stringify({ name, phone }));
    localStorage.setItem('lastCheckedInUserName', name);


    checkIn({ name, phone, project: customProject, task: customTask });
    
    setTimeout(() => {
      setIsSubmitting(false);
      navigate('/'); 
    }, 1500); 
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 flex flex-col items-center justify-center p-4 selection:bg-primary selection:text-white">
       <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="absolute top-6 left-6"
      >
        <Button variant="outline" onClick={() => navigate('/')} className="elegant-button shadow-md">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Volver
        </Button>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 120 }}
        className="text-center mb-8"
      >
        <Building2 className="mx-auto h-16 w-16 text-primary mb-3 filter drop-shadow-md" />
        <h1 className="text-4xl font-extrabold text-gray-800">Registrar Entrada</h1>
        <p className="text-lg text-gray-600 mt-2">Completa tus datos para iniciar jornada.</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="w-full max-w-lg"
      >
        <Card className="border-gray-200 shadow-xl bg-white">
          <CardContent className="p-6 sm:p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name" className="text-gray-700 font-medium text-base">Nombre Completo</Label>
                <div className="relative mt-1">
                  <User className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    id="name"
                    name="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ej: Juan Pérez Rodríguez"
                    className="pl-11 h-14 text-base border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="phone" className="text-gray-700 font-medium text-base">Teléfono</Label>
                 <div className="relative mt-1">
                  <Phone className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Ej: 55 1234 5678"
                    className="pl-11 h-14 text-base border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                    required
                  />
                </div>
              </div>

              {todaysAssignments.length > 0 && (
                <div>
                    <Label htmlFor="assignment" className="text-gray-700 font-medium text-base">Seleccionar Tarea Asignada (Opcional)</Label>
                    <div className="relative mt-1">
                         <CheckSquare className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Select onValueChange={setSelectedAssignmentId} value={selectedAssignmentId}>
                            <SelectTrigger className="w-full pl-11 h-14 text-base border-gray-300 focus:border-primary focus:ring-primary shadow-sm">
                                <SelectValue placeholder="Selecciona una tarea o ingresa manualmente" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="">Ingresar manualmente</SelectItem>
                                {todaysAssignments.map(assignment => (
                                    <SelectItem key={assignment.id} value={assignment.id}>
                                        {assignment.project} - {assignment.task}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
              )}

              <div>
                <Label htmlFor="project" className="text-gray-700 font-medium text-base">Proyecto Asignado</Label>
                <div className="relative mt-1">
                  <Briefcase className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    id="project"
                    name="project"
                    value={customProject}
                    onChange={(e) => setCustomProject(e.target.value)}
                    placeholder="Ej: Torre Reforma LAT"
                    className="pl-11 h-14 text-base border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                    required
                    disabled={!!selectedAssignmentId}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="task" className="text-gray-700 font-medium text-base">Tarea Específica</Label>
                <div className="relative mt-1">
                  <ClipboardList className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    id="task"
                    name="task"
                    value={customTask}
                    onChange={(e) => setCustomTask(e.target.value)}
                    placeholder="Ej: Supervisión de acabados Nivel 7"
                    className="pl-11 h-14 text-base border-gray-300 focus:border-primary focus:ring-primary shadow-sm"
                    required
                    disabled={!!selectedAssignmentId}
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full h-14 text-lg bg-primary hover:bg-blue-700 text-white font-semibold shadow-md hover:shadow-lg transition-shadow"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Registrando Entrada...' : 'Confirmar Entrada y Ubicación'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default CheckInPage;
