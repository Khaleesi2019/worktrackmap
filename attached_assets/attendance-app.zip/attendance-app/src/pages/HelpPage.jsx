
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { ArrowLeft, LogIn, LogOut, MapPin, AlertTriangle, Building2 } from 'lucide-react';

const HelpPage = () => {
  const navigate = useNavigate();

  const helpSections = [
    {
      icon: <LogIn className="h-6 w-6 text-primary" />,
      title: "Registrar Entrada",
      steps: [
        "Presiona el botón 'Entrada' en la pantalla principal.",
        "Completa el formulario con tu Nombre, Teléfono, Proyecto Asignado y Tarea Asignada.",
        "Presiona 'Continuar y Solicitar Ubicación'.",
        "Asegúrate de permitir el acceso a tu ubicación cuando el navegador lo solicite.",
        "Tu entrada y ubicación inicial serán registradas."
      ]
    },
    {
      icon: <LogOut className="h-6 w-6 text-primary" />,
      title: "Registrar Salida",
      steps: [
        "Presiona el botón 'Salida' en la pantalla principal.",
        "Confirma tu salida.",
        "Tu ubicación final será registrada y tu jornada finalizará."
      ]
    },
    {
      icon: <MapPin className="h-6 w-6 text-primary" />,
      title: "Ver Mapa",
      steps: [
        "Presiona el botón 'Mapa' en la pantalla principal.",
        "Verás tu ubicación actual en el mapa.",
        "Tu ubicación se actualiza automáticamente mientras tengas una sesión activa."
      ]
    },
    {
      icon: <AlertTriangle className="h-6 w-6 text-destructive" />,
      title: "Solución de Problemas",
      steps: [
        "Si la ubicación no se registra, verifica los permisos de ubicación de tu navegador para esta página.",
        "Asegúrate de tener una conexión a internet estable.",
        "Si los problemas persisten, contacta a tu supervisor o al departamento de TI."
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mb-6 flex items-center justify-between"
      >
        <Button variant="outline" onClick={() => navigate('/')} className="elegant-button">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Volver
        </Button>
         <div className="flex items-center">
          <Building2 className="h-8 w-8 text-primary mr-2" />
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">Centro de Ayuda</h1>
        </div>
        <div></div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {helpSections.map((section, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
          >
            <Card className="h-full shadow-lg border-gray-200 hover:shadow-xl transition-shadow">
              <CardHeader className="flex flex-row items-center space-x-3 pb-3">
                {section.icon}
                <CardTitle className="text-xl text-gray-700">{section.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-decimal list-inside space-y-2 text-gray-600">
                  {section.steps.map((step, stepIndex) => (
                    <li key={stepIndex}>{step}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
       <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="mt-8 text-center text-gray-500"
      >
        <p>&copy; {new Date().getFullYear()} Master Construction. Todos los derechos reservados.</p>
      </motion.div>
    </div>
  );
};

export default HelpPage;
