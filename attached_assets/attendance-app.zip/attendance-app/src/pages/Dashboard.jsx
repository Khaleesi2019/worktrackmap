
import React from 'react';
import { Navigate } from 'react-router-dom';

// This page is no longer the main entry point.
// Redirecting to the new EmployeeDashboard.
const Dashboard = () => {
  return <Navigate to="/" replace />;
};

export default Dashboard;
