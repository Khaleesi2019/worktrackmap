
import React from 'react';
import { Navigate } from 'react-router-dom';

// This page is no longer used.
// User registration is not part of the new requirements.
const Register = () => {
  return <Navigate to="/" replace />;
};

export default Register;
