
import React from 'react';
import { Navigate } from 'react-router-dom';

// This page is no longer used in this specific flow.
// Details are shown within admin logs or employee map view.
const EmployeeDetailPage = () => {
  return <Navigate to="/" replace />;
};

export default EmployeeDetailPage;
