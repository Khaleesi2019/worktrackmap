
import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { format, differenceInHours, isToday } from 'date-fns';
import { es } from 'date-fns/locale';

const EmployeeContext = createContext();

export const useEmployees = () => useContext(EmployeeContext);

export const EmployeeProvider = ({ children }) => {
  const [employeeLogs, setEmployeeLogs] = useState([]);
  const [currentEmployee, setCurrentEmployee] = useState(null);
  const [futureAssignments, setFutureAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const storedLogs = localStorage.getItem('employeeLogs');
    if (storedLogs) setEmployeeLogs(JSON.parse(storedLogs));
    
    const storedCurrentEmployee = localStorage.getItem('currentEmployee');
    if (storedCurrentEmployee) setCurrentEmployee(JSON.parse(storedCurrentEmployee));
    
    const storedAssignments = localStorage.getItem('futureAssignments');
    if (storedAssignments) setFutureAssignments(JSON.parse(storedAssignments));
    
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!loading) {
      localStorage.setItem('employeeLogs', JSON.stringify(employeeLogs));
      localStorage.setItem('futureAssignments', JSON.stringify(futureAssignments));
      if (currentEmployee) {
        localStorage.setItem('currentEmployee', JSON.stringify(currentEmployee));
      } else {
        localStorage.removeItem('currentEmployee');
      }
    }
  }, [employeeLogs, currentEmployee, futureAssignments, loading]);

  const getCurrentLocation = (callback) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`)
            .then(response => response.json())
            .then(data => {
              callback({
                lat: latitude,
                lng: longitude,
                address: data.display_name || 'Ubicación desconocida',
                timestamp: new Date().toISOString()
              });
            })
            .catch(() => {
              callback({
                lat: latitude,
                lng: longitude,
                address: 'Ubicación (sin dirección detallada)',
                timestamp: new Date().toISOString()
              });
            });
        },
        (error) => {
          toast({
            title: "Error de ubicación",
            description: "No se pudo obtener la ubicación. Asegúrate de tener los permisos activados.",
            variant: "destructive",
          });
          console.error("Error getting location:", error);
          callback(null);
        }
      );
    } else {
      toast({
        title: "Geolocalización no soportada",
        description: "Tu navegador no soporta geolocalización.",
        variant: "destructive",
      });
      callback(null);
    }
  };
  
  const checkIn = (employeeData) => {
    getCurrentLocation((locationData) => {
      if (!locationData) {
        toast({ title: "Registro cancelado", description: "No se pudo obtener la ubicación para el registro de entrada.", variant: "destructive" });
        return;
      }
      const newLog = {
        id: Date.now().toString(),
        employeeName: employeeData.name,
        employeeId: employeeData.employeeId || employeeData.name.toLowerCase().replace(/\s+/g, '-'), // Create an ID if not present
        phone: employeeData.phone,
        project: employeeData.project,
        task: employeeData.task,
        timeIn: new Date().toISOString(),
        locationIn: locationData,
        timeOut: null,
        locationOut: null,
        status: 'active',
        lastLocationUpdate: locationData.timestamp,
        avatarInitial: employeeData.name.charAt(0).toUpperCase(), // For map marker
      };
      setEmployeeLogs(prev => [...prev, newLog]);
      setCurrentEmployee(newLog);
      toast({
        title: "Entrada registrada",
        description: `${employeeData.name} ha registrado su entrada.`,
      });
    });
  };

  const checkOut = () => {
    if (!currentEmployee) {
      toast({ title: "Error", description: "No hay un registro de entrada activo.", variant: "destructive" });
      return;
    }
    getCurrentLocation((locationData) => {
      // Even if location fails for checkout, proceed with checkout but without locationOut
      const finalLocation = locationData || { address: "No se pudo obtener ubicación de salida", lat: null, lng: null, timestamp: new Date().toISOString() };

      setEmployeeLogs(prev => 
        prev.map(log => 
          log.id === currentEmployee.id 
          ? { ...log, timeOut: new Date().toISOString(), locationOut: finalLocation, status: 'inactive' } 
          : log
        )
      );
      const checkedOutEmployeeName = currentEmployee.employeeName;
      setCurrentEmployee(null); // Clear current employee session
      localStorage.removeItem('currentEmployee'); // Ensure it's cleared
      toast({
        title: "Salida registrada",
        description: `${checkedOutEmployeeName} ha registrado su salida.`,
      });
    });
  };

  const updateCurrentEmployeeLocation = () => {
    if (currentEmployee && currentEmployee.status === 'active') {
      getCurrentLocation((locationData) => {
        if (locationData) {
          const updatedLogEntry = { 
            ...currentEmployee, 
            locationIn: locationData, // Overwrites previous locationIn with current for active tracking
            lastLocationUpdate: locationData.timestamp 
          };
          
          setEmployeeLogs(prevLogs =>
            prevLogs.map(log =>
              log.id === currentEmployee.id
                ? updatedLogEntry
                : log
            )
          );
          setCurrentEmployee(updatedLogEntry);
          toast({
            title: "Ubicación actualizada",
            description: `La ubicación de ${currentEmployee.employeeName} ha sido actualizada.`,
            variant: "default"
          });
        }
      });
    }
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (currentEmployee && currentEmployee.status === 'active') {
        updateCurrentEmployeeLocation();
      }
    }, 30 * 60 * 1000); 

    return () => clearInterval(intervalId);
  }, [currentEmployee]);


  const calculateHours = (timeIn, timeOut) => {
    if (!timeIn || !timeOut) return 'N/A';
    const hours = differenceInHours(new Date(timeOut), new Date(timeIn));
    const minutes = Math.floor((new Date(timeOut) - new Date(timeIn)) / (1000 * 60)) % 60;
    return `${hours}h ${minutes < 10 ? '0' : ''}${minutes}m`;
  };

  const addFutureAssignment = (assignment) => {
    const newAssignment = {
      id: Date.now().toString(),
      ...assignment,
      assignedAt: new Date().toISOString(),
    };
    setFutureAssignments(prev => [...prev, newAssignment]);
    toast({
      title: "Tarea asignada",
      description: `Nueva tarea para ${assignment.employeeName} el ${format(new Date(assignment.date), 'PPP', { locale: es })}.`
    });
  };
  
  const getTodaysAssignmentsForEmployee = (employeeName) => {
    if (!employeeName) return [];
    return futureAssignments.filter(
      (assign) => assign.employeeName === employeeName && isToday(new Date(assign.date))
    );
  };

  const value = {
    employeeLogs,
    currentEmployee,
    futureAssignments,
    loading,
    checkIn,
    checkOut,
    calculateHours,
    updateCurrentEmployeeLocation,
    getCurrentLocation,
    setCurrentEmployee,
    addFutureAssignment,
    getTodaysAssignmentsForEmployee,
  };

  return (
    <EmployeeContext.Provider value={value}>
      {children}
    </EmployeeContext.Provider>
  );
};
