
import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

const ADMIN_PIN = "1020";

export const AuthProvider = ({ children }) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const storedAuth = localStorage.getItem('isAdminAuthenticated');
    if (storedAuth === 'true') {
      setIsAdminAuthenticated(true);
    }
    setLoading(false);
  }, []);

  const adminLogin = (pin) => {
    if (pin === ADMIN_PIN) {
      setIsAdminAuthenticated(true);
      localStorage.setItem('isAdminAuthenticated', 'true');
      toast({
        title: "Acceso concedido",
        description: "Bienvenido al panel de administración.",
      });
      navigate('/admin/dashboard');
      return true;
    } else {
      toast({
        title: "Acceso denegado",
        description: "PIN incorrecto.",
        variant: "destructive",
      });
      return false;
    }
  };

  const adminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('isAdminAuthenticated');
    toast({
      title: "Sesión de administrador cerrada",
    });
    navigate('/admin/login');
  };
  
  const value = {
    isAdminAuthenticated,
    adminLogin,
    adminLogout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
