# About

Derived from https://github.com/H-M-H/Weylus/tree/master/src/capturable with the author's consent, https://github.com/rustdesk/rustdesk/issues/56#issuecomment-882727967 

# Dep

Works fine on Ubuntu 21.04 with pipewire 3 and xdg-desktop-portal 1.8

`
apt install -y libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev
`
