# Policy sicurezza

## Segnalazione di una vulnerabilità

Attribuiamo grande importanza alla sicurezza del progetto. 
Incoraggiamo tutti gli utenti a segnalare eventuali vulnerabilità di sicurezza che ci scoprono.
Se trovi una vulnerabilità nel progetto RustDesk, segnalala responsabilmente inviando un'email a info@rustdesk.com.

Al momento non abbiamo un programma di taglia sui bug.
Siamo una piccola squadra che cerca di risolvere un grosso problema. 
Ti esortiamo a segnalare responsabilmente tutte le vulnerabilità in modo da poter continuare a sviluppare un'applicazione sicura per l'intera comunità.
