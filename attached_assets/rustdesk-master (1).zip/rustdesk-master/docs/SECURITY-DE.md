# Sicherheitsrichtlinie

## Melden einer Schwachstelle

Wir legen großen Wert auf die Sicherheit des Projekts. Wir ermutigen alle Benutzer, uns alle Sicherheitslücken zu melden, die sie entdecken.
Wenn Sie eine Sicherheitslücke im RustDesk-Projekt finden, melden Sie diese bitte verantwortungsbewusst per E-Mail an info@rustdesk.com.

Zum jetzigen Zeitpunkt haben wir kein Bug-Bounty-Programm. Wir sind ein kleines Team, das versucht, ein großes Problem zu lösen. Wir bitten Sie dringend,
alle Schwachstellen verantwortungsbewusst zu melden, damit wir weiterhin eine sichere Anwendung für die ganze Gemeinschaft entwickeln können.
